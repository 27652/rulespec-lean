# RuleSpecLean v0.1

A prototype for lowering a **restricted snapshot of RuleSpec compiled artifact v3**
to a deep embedding in Lean 4. No language model is involved in conversion.

## Verification status (2026-11-26)

- Python converter executed on the supplied **synthetic** v3-shaped CTC-like
  fixture: 7 rules generated.
- 18 Python unittest methods passed, including 10,000 seeded randomized
  cases compared with a separately written integer/Fraction tax-credit formula.
- Lean runtime, generated terms, three candidate theorems and 13 `#guard`
  assertions are included. **Lean was not installed, so none of these have
  been compiled or kernel-checked here.**
- No genuine Axiom compiled artifact was obtained or evaluated; no Rust
  reference-engine comparison has been performed. No upstream coverage rate
  or legal accuracy rate is claimed. CI is supplied but was not run.
- A subprocess printed an unrelated spreadsheet-runtime startup warning;
  converter and test process exit codes were both zero.

The fixture is a simplified, CTC-like calculation with precomputed eligible
dependent counts. It is not a complete implementation of 26 USC §24, a filing
calculator, or an artifact produced/accepted by the official engine. Its
`interface`/metadata are deliberately synthetic placeholders.

## Quick start (Python 3.10+)

From the repository root:

```sh
python -m unittest -v tools.test_prototype
python tools/compile_ir.py fixtures/ctc-like.artifact.json \
    --as-of 2025-01-01 --output credit
python -m tools.scan_artifacts fixtures --as-of 2025-01-01
```

The conversion emits `RuleSpecLean/Generated.lean` and
`generated-manifest.json`. The manifest records source identity, input SHA-256,
snapshot date, output names and rule provenance. Internal IR names are used
for `--output`. Each dependency is declared before rules that reference it.

For an execution of the fixture's Python mirror:

```sh
python -c 'from tools.test_prototype import *; c=Compiler(FIXTURE,"2025-01-01"); c.compile(["credit"]); print(run(c.normal["credit"],env(),c.normal))'
```

Expected: `('decimal', 4800000000)` = $4,800 at scale 6.

## Lean build (requires elan / Lean 4)

The project selects Lean 4.26.0, without Mathlib. Install elan using the
official Lean installation instructions, then:

```sh
lake build
```

The `RuleSpecLean.Tests` module runs the sample, boundary/error assertions,
and imports the candidate theorems in `Core.lean`. If any Lean build error
occurs, treat it as an open issue; do not claim verified status. The supplied
GitHub Actions workflow runs Python tests, regenerates the fixture, and invokes
the Lean build. Use the fixture when building the included tests; for other
outputs, generate a separate module or replace the test module.

## Accepted fragment

| Feature | v0.1 behavior |
|---|---|
| Input | Prebound slot -> tagged value for one entity and period |
| Rule references | Acyclic dependency closure; unsupported or cyclic references rejected |
| Numeric literals | Signed i64, plain exact decimal at scale <= 6 |
| Arithmetic | Add, sub, mul, div, min, max, ceil, floor |
| Conditions | Lazy scalar if; undetermined goes to else |
| Comparison | Numeric comparisons, Boolean/text equality and inequality |
| Judgments | Comparison, judgment refs, and/or/not; internal three-valued representation |
| Parameters | Indexed tables, version selected at fixed period start |
| Rule versions | Latest applicable start, last-in-document tie, inclusive end |
| Output rounding | Rejected at lowering |
| Relations and temporal data | Rejected when reached in dependency lowering |
| Provenance | Rule fields and artifact identity copied to manifest |

Numeric contract: decimals have coefficient `c` representing `c / 10^6`,
with `|c| <= 10^21`. Arithmetic is accepted only if every required intermediate
decimal remains in the restricted domain; e.g. `1/3` is an explicit refusal.
This is an exact, conservative subset, **not** a full model of rust_decimal.
Input slots must contain valid supported literal values; invalid inputs are
outside the Python evaluation contract. Date values, input defaults,
cross-period data, relation predicates, aggregate relations, elections as
optimization, request pins, legal output rounding and exact upstream error
messages/traces are not implemented. Direct rule references assume scalar or
judgment kind matches. The adapter does not validate the full artifact
schema, artifact integrity, request binding or namespace rules; upstream
admission is a precondition. Static rejection may include untaken branches.
Missing parameter versions are refused at lowering, not reproduced lazily.

## Try a real artifact

1. Clone and pin both upstream repositories to actual commit hashes:
   - https://github.com/TheAxiomFoundation/axiom-rules-engine
   - https://github.com/TheAxiomFoundation/rulespec-us
2. Build the official Rust engine, consult its CLI (`--help`) and compile a
   small scalar-only tax module to a v3 JSON artifact. Use the official
   validation/loading mechanism before conversion.
3. Inspect `program.derived[].name`, choose a scalar output and run:

```sh
python tools/compile_ir.py /path/to/official-artifact.json \
  --as-of 2025-01-01 --output INTERNAL_RULE_NAME \
  --lean RuleSpecLean/Official.lean --manifest reports/official-manifest.json
```

4. Build `lake build RuleSpecLean.Official`; supply the same valid, prebound
   entity/period facts to the Lean evaluator and Rust Explain. Check values,
   tags and error priority separately. The request adapter for this is the
   next milestone, not included.
5. Use `python -m tools.scan_artifacts /path/to/artifacts --as-of 2025-01-01`
   to inventory static lowering success and blockers. Static success does
   not imply compilation, semantic equivalence, or law coverage.

## Roadmap and proof obligations

1. **Gate A: real interoperability.** Pin commits, obtain a real scalar
   artifact, run upstream Explain and Lean on the same 100+ cases. Complete
   CI and fix all compilation failures. No artifact schema or error mismatch
   should be silently accepted.
2. **Gate B: exact reference numeric semantics.** Implement decimal
   coefficient/scale, all four output-rounding strategies, bounds and overflow.
   Compare with the actual rust_decimal implementation across randomized and
   adversarial tests. Define the admissible domain precisely.
3. **Gate C: data binding and time.** Implement entity ID and interval-based
   input resolution, version lookup in the evaluator, missing values, and
   selected-year inputs. Preserve rule-level rounding before dependencies read.
4. **Gate D: relations.** Support sorted distinct finite relation members,
   count/sum, filters, only and extrema; then relation-role contexts, exists
   and derived relations. Use actual CTC and SNAP modules.
5. **Gate E: semantic-preservation proof.** Define independent formal source
   semantics `evalRS` and translation `lower`. Prove
   `evalRS p d q = evalLean (lower p) d q` for an explicit supported domain.
   For Python code generation either formalize translation in Lean or verify
   translation certificates in Lean. A theorem about the target interpreter
   alone is not a theorem about the Python converter or the Rust engine.
6. **Gate F: corpus analysis.** Run the scanner on real artifacts, report
   compile/lowering/runtime/test coverage with explicit denominators, and
   prove useful tax properties; independently audit legal source versions.

## Upstream references

Consulted public documentation/source (main branch viewed 2026-11-26; exact
upstream HEAD was not pinned in this environment):

- https://github.com/TheAxiomFoundation/axiom-rules-engine/blob/main/src/spec.rs
- https://github.com/TheAxiomFoundation/axiom-rules-engine/blob/main/src/model.rs
- https://github.com/TheAxiomFoundation/axiom-rules-engine/blob/main/src/engine.rs
- https://github.com/TheAxiomFoundation/axiom-rules-engine/blob/main/docs/artifact-format.md
- https://github.com/TheAxiomFoundation/axiom-rules-engine/blob/main/docs/execution-semantics.md

All prototype code is original; the fixture was hand-authored from the
documented wire shape. Not affiliated with Axiom Foundation or Lexifina.
